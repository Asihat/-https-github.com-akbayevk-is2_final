</!DOCTYPE html>
<html>
<head>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
<meta charset=utf-8 />
	<title></title>
</head>
<body>
<div id="area-example" style="height: 250px;"></div>
</body>
</html>
<a href="/post">Main menu</a>


<script type="text/javascript">
	
	new Morris.Area({
  element: 'area-example',
  behaveLikeLine: true,
  parseTime : false, 
  data: [
    @foreach($table_info as $sale)
        {'months': '{{ $sale->months }}', 'value': '{{ $sale->value}}' },
    @endforeach
],

  
  xkey: 'months',
  ykeys: ['value'],
   labels: ['AVG '],
  pointFillColors: ['#707f9b'],
  pointStrokeColors: ['#ffaaab'],
  redraw: true, 
 
});

</script>
