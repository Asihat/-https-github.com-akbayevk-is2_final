
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
<meta charset=utf-8 />
<title>Morris.js Donut Chart Example</title>
</head>
<body>
<div id="donut-example" style="height: 350px;"><h2>Average salary of department employees</h2></div>
<br>
<br>
<div id="area-example" style="height: 450px;"> <h2>Revenue growth in the HR Department</h2></div>
<br>
<br>
<div id="bar-example" style="height: 250px;"><h2>Revenue growth in the Marketing Department</h2></div>
<br>
<br>
<br>
<div id="gender-example" style="height: 250px;"><h2>Number of Men and Women</h2></div>
<br>
<br>
</body>
</html>
<a href="/post" style="margin-left: 100px;">Main menu</a>

<script type="text/javascript">


// var data1 =  '{{ json_encode($dep) }}'
//data1= JSON.parse('{{ $dep }}');
//console.log(data1)
//document.write("У Вас включён JavaScript!");

new Morris.Donut({
  element: 'donut-example',
 
  data: [
    @foreach($dep as $sale)
        {'label': '{{ $sale->label }}', 'value': '{{ $sale->value}}'},
    @endforeach
],

formatter: function (value, data) { 
      var valor = value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
      return parseFloat(valor); 
    }

//parseTime: false,
});

new Morris.Donut({
  element: 'gender-example',
 
  data: [
    @foreach($gend as $sale)
        {'label': '{{ $sale->label }}', 'value': '{{ $sale->value}}'},
    @endforeach
],

 colors: ['#64dd17', '#f4511e', '#9e9d24']


//parseTime: false,
});


new Morris.Area({
  element: 'area-example',
  behaveLikeLine: true,
  parseTime : false, 
  data: [
    @foreach($wage as $sale)
        {'months': '{{ $sale->months }}', 'value': '{{ $sale->value}}' },
    @endforeach
],

  
  xkey: 'months',
  ykeys: ['value'],
   labels: ['AVG '],
  pointFillColors: ['#707f9b'],
  pointStrokeColors: ['#ffaaab'],
  lineColors: ['#f26c4f', '#00a651', '#00bff3'],
  redraw: true, 
 
});

new Morris.Bar({
  element: 'bar-example',
  behaveLikeLine: true,
  parseTime : false, 
  data: [
    @foreach($bar as $sale)
        {'months': '{{ $sale->months }}', 'value': '{{ $sale->value1}}'},
    @endforeach
],

  
  xkey: 'months',
  ykeys: ['value'],
  labels: ['AVG '],
  pointFillColors: ['#707f9b'],
  pointStrokeColors: ['#ffaaab'],
 barColors: ["#212121", "#1531B2", "#795548", "#B29215"],
  
 
});

</script>
