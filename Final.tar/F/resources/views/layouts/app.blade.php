<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Final project</title>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>
        <!-- Bootstrap Core CSS -->
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <!-- Flaticon CSS -->
      <link href="fonts/flaticon/flaticon.css" rel="stylesheet">
      <!-- font-awesome CSS -->
      <link href="css/font-awesome.min.css" rel="stylesheet">
      <!-- Offcanvas CSS -->


<!--<link rel="stylesheet" type="text/css" href="css/main.css">-->



      <link href="css/hippo-off-canvas.css" rel="stylesheet">
      <!-- animate CSS -->
      <link href="css/animate.css" rel="stylesheet">
      <!-- language CSS -->
      <link href="css/language-select.css" rel="stylesheet">
      <!-- owl.carousel CSS -->
      <link href="owl.carousel/assets/owl.carousel.css" rel="stylesheet">
    <!-- magnific-popup -->
      <link href="css/magnific-popup.css" rel="stylesheet">
      <!-- Main menu -->
      <link href="css/menu.css" rel="stylesheet">
      <!-- Template Common Styles -->
      <link href="css/template.css" rel="stylesheet">
      <!-- Custom CSS -->
      <link href="css/style.css" rel="stylesheet">
      <!-- Responsive CSS -->
      <link href="css/responsive.css" rel="stylesheet">

      <script src="js/vendor/modernizr-2.8.1.min.js"></script>



  </head>
  

<body id="page-top">

<div id="st-container" class="st-container">
        <div class="st-pusher">
            <div class="st-content">
            <header class="header">
              <nav class="top-bar">
                <div class="overlay-bg">
                  <div class="container">
                    <div class="row">
                      
                      <div class="col-sm-6 col-xs-12">
                        <div class="call-to-action">
                          <ul class="list-inline">
                            <li><a href="#"><i class="fa fa-phone"></i> 7-777-777-777</a></li>
                            <li><a href="#"><i class="fa fa-envelope"></i> admin@domain.com</a></li>
                          </ul>
                        </div><!-- /.call-to-action -->
                      </div><!-- /.col-sm-6 -->

                      <div class="col-sm-6 hidden-xs">
                        <div class="topbar-right">
                          <div class="lang-support pull-right">
                          <select class="cs-select cs-skin-elastic">
                            <option value="" disabled selected>Language</option>
                            <option value="united-kingdom" data-class="flag-uk">English</option>
                            <option value="france" data-class="flag-france">French</option>
                            <option value="spain" data-class="flag-spain">Spanish</option>
                            <option value="south-africa" data-class="flag-bd">Bengali</option>
                          </select>
                        </div>

                          <ul class="social-links list-inline pull-right">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="#"><i class="fa fa-tumblr"></i></a></li>
                          </ul>
                        </div><!-- /.social-links -->
                      </div><!-- /.col-sm-6 -->
                      
                    </div><!-- /.row -->
                  </div><!-- /.container -->
                </div><!-- /.overlay-bg -->
              </nav><!-- /.top-bar -->

              <div id="search">
                <button type="button" class="close">×</button>
                <form>
                    <input type="search" value="" placeholder="type keyword(s) here" />
                    <button type="submit" class="btn btn-primary">Search</button>
                </form>
            </div>
            
            <nav class="navbar navbar-default" role="navigation">
              
              <div class="container mainnav">
                <div class="navbar-header">
                  <h1 class="logo"><a class="navbar-brand" href="/post"><img src="img/logo.png" alt=""></a></h1>

                  <!-- offcanvas-trigger -->
                              <button type="button" class="navbar-toggle collapsed pull-right" >
                                <span class="sr-only">Toggle navigation</span>
                                <i class="fa fa-bars"></i>
                              </button>

                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse navbar-collapse">

                  

                          <span class="search-button pull-right"><a href="#search"><i class="fa fa-search"></i></a></span>

                  <ul class="nav navbar-nav navbar-right">
                    <!-- Home -->
                                        <li class="dropdown active"><a href="/post">Home <span class="fa fa-angle-down"></span></a>
                                            <!-- submenu-wrapper -->
                                            <div class="submenu-wrapper">
                                                <div class="submenu-inner">
                                                 
                                                </div>
                                            </div>
                                            <!-- /submenu-wrapper -->
                                        </li>
                                        <!-- /Home -->

                                        <!-- Pages -->
                                        <li class="dropdown"><a href="#">Pages <span class="fa fa-angle-down"></span></a>
                                            <!-- submenu-wrapper -->
                                            <div class="submenu-wrapper">
                                                <div class="submenu-inner">
                                                    <ul class="dropdown-menu">
                                                      <li><a href="/about">About</a></li>
                                                        <li><a href="/info">Managers</a></li>
                                                        <li><a href="/depinfo">Statistics</a></li>
                                                        
                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- /submenu-wrapper -->
                                        </li>
                                        <!-- /Pages -->

                                        <!-- Services -->
                                       
                                        <!-- MEGA MENU -->
                    <!-- /MEGA MENU -->
                                        <!-- /Pages -->
                    <!-- Blog -->
                                      
                  </ul>
                </div><!-- /.navbar-collapse -->
              </div><!-- /.container -->

              
            </nav>
          </header>
<div class="container">
  @yield('content')
</div>
</div>
</div>
</div>





















<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script type="text/javascript">
{{-- ajax Form Add Post--}}
  // Show function
  $(document).on('click', '.show-modal', function() {
  $('#show').modal('show');
  $('#i').text($(this).data('id'));
  $('#ti').text($(this).data('title'));
  $('#by').text($(this).data('body'));
  $('#day').text($(this).data('birth'));
  $('#hday').text($(this).data('hire'));
  $('#gender').text($(this).data('gender'));
  $('.modal-title').text('Show Post');
  });

</script>


   <!--page js-->
    <script src="js/jquery.js"></script>
      <!-- Bootstrap Core JavaScript -->
      <script src="js/bootstrap.min.js"></script>
      <!-- owl.carousel -->
      <script src="owl.carousel/owl.carousel.min.js"></script>
      <!-- Magnific-popup -->
    <script src="js/jquery.magnific-popup.min.js"></script>
    <!-- Offcanvas Menu -->
    <script src="js/hippo-offcanvas.js"></script>
    <!-- inview -->
    <script src="js/jquery.inview.min.js"></script>
    <!-- stellar -->
    <script src="js/jquery.stellar.js"></script>
    <!-- countTo -->
    <script src="js/jquery.countTo.js"></script>
    <!-- classie -->
    <script src="js/classie.js"></script>
    <!-- selectFx -->
    <script src="js/selectFx.js"></script>
    <!-- sticky kit -->
    <script src="js/jquery.sticky-kit.min.js"></script>
      <!-- GOGLE MAP -->
      <script src="https://maps.googleapis.com/maps/api/js"></script>
      <!--TWITTER FETCHER-->
      <script src="js/twitterFetcher_min.js"></script>
      <!-- Custom Script -->
      <script src="js/scripts.js"></script>

  </body>
</html>