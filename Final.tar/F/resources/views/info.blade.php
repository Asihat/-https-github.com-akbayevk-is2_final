<!DOCTYPE html>
<html>
<head>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

	<title>Manager</title>

</head>
<body>
<a href="/post">Main menu</a>

<div class="container">
  <h2>Department manegers</h2>
  <p>The .table class adds basic styling (light padding and only horizontal dividers) to a table:</p>            
  

  <table class="table table-striped table-bordered">
    <thead>
      <tr>
      	<th>№</th>
        <th>Firstname</th>
        <th>Departments</th>
        <th>FromDate</th>
      </tr>
    </thead>
    <?php 
	$no = 1;
	foreach ($top as $key => $value) {
		?>

	<tr>
		<th><?php echo $no++; ?></th>
		<th><a class="btn btn-default" href="/info_manager?id={{ $value -> ID }}" ><?php echo $value->FirstName; ?></a></th>
		<th><?php echo $value->DeptName; ?></th>
		<th><?php echo $value->FromDate; ?></th>
	

.
	</tr>

		<?php 
	}
	?>
  </table>
</div>
</body>
</html>