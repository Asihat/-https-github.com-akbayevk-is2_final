{{-- calling layouts \ app.blade.php --}}
@extends('layouts.app')
@section('content')

  <div class="col-md-12">
    <h1>Information about employees</h1>
  </div>

<div class="row">
    <div class="container">
      Filter <br>
      <form action="/post?name=find" method="POST" role="search">
          {{ csrf_field() }}
          <div class="input-group">

              <input type="text" class="form-control" name="last_name"
                  placeholder="Search last_name">
              <input type="text" class="form-control" name="first_name"
                  placeholder="Search first_namet"> <span class="input-group-btn">

                  <button type="submit" class="btn btn-default">
                      <span class="glyphicon glyphicon-search"></span>
                  </button>

              </span>
          </div>
      </form>
        <br>
<div class="container">                    

    <ul class="nav navbar-nav navbar-right">
                    <!-- Home -->
                                        <li class="dropdown active"><a href="#">Category <span class="fa fa-angle-down"></span></a>
                                            <!-- submenu-wrapper -->
                                            <div class="submenu-wrapper">
                                                <div class="submenu-inner">
                                                    <ul class="dropdown-menu">
                                                            <?php
                                                                  foreach ($cat as $key => $value) {
                                                                   ?>
                                                                      
                                                      <li><a href="/post?type={{ $value -> dept_name }}">{{ $value -> dept_name }}</a></li>
                                                            

                                                                <?php  
                                                                  }
                                                                ?>  
                                                    </ul>
                                                </div>
                                            </div>
                                        </li>
                                
                  </ul>

    <!--              
    <ul class="dropdown-menu">
        <?php
            foreach ($cat as $key => $value) {
              ?>
                
          <li><a href="/post?type={{ $value -> dept_name }}">{{ $value -> dept_name }}</a></li>      
        
        <?php
            }
        ?>

    </ul>
    -->
  </div>
</div>
       <br>
      <a href="/post">Reset</a><br>
      <br>
    </div>
</div>
<div class="row left">
  <div class="table table-responsive">
    <table class="table table-bordered" id="table">
      <tr>
        <th width="150px" class="left">No</th>
        <th>FirstName</th>
        <th>LastName</th>
        <th>Hire date</th>
        <th class="text-center" width="150px">
          
        </th>
      </tr>
      {{ csrf_field() }}
      <?php  $no=1; ?>
      @foreach ($post as $value)
        <tr class="post{{$value->id}}">
          <td><a href="/portfolio?id={{ $value->emp_no }}">{{ $value->emp_no }}</a></td>
          <td>{{ $value->first_name }}</td>
          <td>{{ $value->last_name }}</td>
          <td>{{ $value->hire_date }}</td>
          <td>
            <a href="#" class="show-modal btn btn-info btn-sm" data-id="{{$value->emp_no}}" data-title="{{$value->first_name}}" data-body="{{$value->last_name}}" data-birth="{{$value->birth_date}}" 
            data-gender="{{$value->gender}}" data-hire="{{$value->hire_date}}">
              <i class="fa fa-eye"></i>
            
          </td>
        </tr>
      @endforeach
    </table>
  </div>
  {{$post->links()}}
</div>

{{-- Modal Form Show POST --}}
<div id="show" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"></h4>
                  </div>
                    <div class="modal-body">
                    <div class="form-group">
                      <label for="">ID :</label>
                      <b id="i"/>
                    </div>
                    <div class="form-group">
                      <label for="">First Name :</label>
                      <b id="ti"/>
                    </div>
                    <div class="form-group">
                      <label for="">Last Name :</label>
                      <b id="by"/>
                    </div>
                    
                    <div class="form-group">
                      <label for="">Birthday :</label>
                      <b id="day"></b>
                    </div>

                    <div class="form-group">
                      <label for="">Gender :</label>
                      <b id="gender"></b>
                    </div>

                    <div class="form-group">
                      <label for="">Hire date :</label>
                      <b id="hday"></b>
                    </div>
                    </div>
                    </div>
                  </div>
</div>

<section class="testimonial-section section-padding">
                  <div class="container text-center">
                    
                    <hr>

                    <div class="partner-section">
                      <div class="row row-content">
                        <div class="col-md-12">
                  <div class="owl-carousel partner-carousel">
                      <div class="item">
                        <a href="#"><img src="img/partner/p1.jpg" alt=""></a>
                      </div>
                      <div class="item">
                        <a href="#"><img src="img/partner/p2.jpg" alt=""></a>
                      </div>
                      <div class="item">
                        <a href="#"><img src="img/partner/p3.jpg" alt=""></a>
                      </div>
                      <div class="item">
                        <a href="#"><img src="img/partner/p4.jpg" alt=""></a>
                      </div>
                      <div class="item">
                        <a href="#"><img src="img/partner/p5.jpg" alt=""></a>
                      </div>
                      <div class="item">
                        <a href="#"><img src="img/partner/p1.jpg" alt=""></a>
                      </div>
                      <div class="item">
                        <a href="#"><img src="img/partner/p2.jpg" alt=""></a>
                      </div>
                      <div class="item">
                        <a href="#"><img src="img/partner/p3.jpg" alt=""></a>
                      </div>
                      <div class="item">
                        <a href="#"><img src="img/partner/p4.jpg" alt=""></a>
                      </div>
                  </div>


                      <div class="partner-carousel-navigation">
                          <a class="prev"><i class="fa fa-angle-left"></i></a>
                          <a class="next"><i class="fa fa-angle-right"></i></a>
                      </div><!-- /.partner-carousel-navigation -->


                        </div><!-- /.col-md-12 -->
                      </div><!-- /.row -->
                    </div><!-- /.partner-section -->
                  </div><!-- /.container -->
              </section>
               <footer class="copyright-section">
                <div class="container text-center">
                  <div class="footer-menu">
                    <ul>
                      <li><a href="#">Privacy &amp; Cookies</a></li>
                      <li><a href="#">Terms &amp; Conditions</a></li>
                      <li><a href="#">Accessibility</a></li>
                    </ul>
                  </div>

                  <div class="copyright-info">
                    <span>Copyright © 2018 Unship. All Rights Reserved.</span>
                  </div>
                </div><!-- /.container -->
              </footer>



@endsection
