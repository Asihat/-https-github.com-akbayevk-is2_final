<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- table css-->

<!--	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">-->

	
	<!-- page css-->
	<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>
        <!-- Bootstrap Core CSS -->
	    <link href="css/bootstrap.min.css" rel="stylesheet">
	    <!-- Flaticon CSS -->
	    <link href="fonts/flaticon/flaticon.css" rel="stylesheet">
	    <!-- font-awesome CSS -->
	    <link href="css/font-awesome.min.css" rel="stylesheet">
	    <!-- Offcanvas CSS -->

<link rel="stylesheet" type="text/css" href="css/main.css">



	    <link href="css/hippo-off-canvas.css" rel="stylesheet">
	    <!-- animate CSS -->
	    <link href="css/animate.css" rel="stylesheet">
	    <!-- language CSS -->
	    <link href="css/language-select.css" rel="stylesheet">
	    <!-- owl.carousel CSS -->
	    <link href="owl.carousel/assets/owl.carousel.css" rel="stylesheet">
		<!-- magnific-popup -->
    	<link href="css/magnific-popup.css" rel="stylesheet">
    	<!-- Main menu -->
    	<link href="css/menu.css" rel="stylesheet">
    	<!-- Template Common Styles -->
    	<link href="css/template.css" rel="stylesheet">
	    <!-- Custom CSS -->
	    <link href="css/style.css" rel="stylesheet">
	    <!-- Responsive CSS -->
	    <link href="css/responsive.css" rel="stylesheet">

	    <script src="js/vendor/modernizr-2.8.1.min.js"></script>

</head>







<body id="page-top">
<div id="st-container" class="st-container">
		    <div class="st-pusher">
	        	<div class="st-content">
				  	<header class="header">
				  		<nav class="top-bar">
				  			<div class="overlay-bg">
					  			<div class="container">
					  				<div class="row">
					  					
					  					<div class="col-sm-6 col-xs-12">
						  					<div class="call-to-action">
						  						<ul class="list-inline">
						  							<li><a href="#"><i class="fa fa-phone"></i> 7-777-777-777</a></li>
						  							<li><a href="#"><i class="fa fa-envelope"></i> admin@domain.com</a></li>
						  						</ul>
						  					</div><!-- /.call-to-action -->
					  					</div><!-- /.col-sm-6 -->

					  					<div class="col-sm-6 hidden-xs">
						  					<div class="topbar-right">
							  					<div class="lang-support pull-right">
													<select class="cs-select cs-skin-elastic">
														<option value="" disabled selected>Language</option>
														<option value="united-kingdom" data-class="flag-uk">English</option>
														<option value="france" data-class="flag-france">French</option>
														<option value="spain" data-class="flag-spain">Spanish</option>
														<option value="south-africa" data-class="flag-bd">Bengali</option>
													</select>
												</div>

						  						<ul class="social-links list-inline pull-right">
						  							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
						  							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
						  							<li><a href="#"><i class="fa fa-instagram"></i></a></li>
						  							<li><a href="#"><i class="fa fa-tumblr"></i></a></li>
						  						</ul>
						  					</div><!-- /.social-links -->
					  					</div><!-- /.col-sm-6 -->
						  				
					  				</div><!-- /.row -->
					  			</div><!-- /.container -->
				  			</div><!-- /.overlay-bg -->
				  		</nav><!-- /.top-bar -->

				  		<div id="search">
						    <button type="button" class="close">×</button>
						    <form>
						        <input type="search" value="" placeholder="type keyword(s) here" />
						        <button type="submit" class="btn btn-primary">Search</button>
						    </form>
						</div>
						
						<nav class="navbar navbar-default" role="navigation">
							
							<div class="container mainnav">
								<div class="navbar-header">
									<h1 class="logo"><a class="navbar-brand" href="/post"><img src="img/logo.png" alt=""></a></h1>

									<!-- offcanvas-trigger -->
			                        <button type="button" class="navbar-toggle collapsed pull-right" >
			                          <span class="sr-only">Toggle navigation</span>
			                          <i class="fa fa-bars"></i>
			                        </button>

								</div>

								<!-- Collect the nav links, forms, and other content for toggling -->
								<div class="collapse navbar-collapse navbar-collapse">

									

					                <span class="search-button pull-right"><a href="#search"><i class="fa fa-search"></i></a></span>

									<ul class="nav navbar-nav navbar-right">
										<!-- Home -->
                                        <li class="dropdown active"><a href="index.html">Home <span class="fa fa-angle-down"></span></a>
                                            <!-- submenu-wrapper -->
                                            <div class="submenu-wrapper">
                                                <div class="submenu-inner">
                                                    <ul class="dropdown-menu">
                                                    	<li><a href="index2.html">Home2</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- /submenu-wrapper -->
                                        </li>
                                        <!-- /Home -->

                                        <!-- Pages -->
                                        <li class="dropdown"><a href="/post">Pages <span class="fa fa-angle-down"></span></a>
                                            <!-- submenu-wrapper -->
                                            <div class="submenu-wrapper">
                                                <div class="submenu-inner">
                                                    <ul class="dropdown-menu">
                                                    	<li><a href="/about">About</a></li>
                                                        <li><a href="service.html">Service</a></li>
                                                        <li><a href="our-people.html">Our people</a></li>
                                                        <li><a href="career.html">Career</a></li>
                                                        <li><a href="faq.html">FAQ Page</a></li>
                                                        <li><a href="typography.html">Typography</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- /submenu-wrapper -->
                                        </li>
                                        <!-- /Pages -->

                                        <!-- Services -->
                                    
                                        <!-- MEGA MENU -->
										<!-- /MEGA MENU -->
                                        <!-- /Pages -->
										<!-- Blog -->
                                        
									</ul>
								</div><!-- /.navbar-collapse -->
							</div><!-- /.container -->

							
						</nav>
					</header>






					<section class="feature-section section-padding">
				        <div class="container">
				        	<div class="row">
				        		<div class="col-sm-7 col-xs-12">
				        			<h1>Portfolio of {{ $user[0]-> first_name }}</h1>

				        			<h3>Name: {{ $user[0]-> first_name }} </h3>
									<h3>Last Name: {{ $user[0]-> last_name }} </h3>
									<h3>Date Of Birthday: {{ $user[0]-> birth_date }}</h3>
									<h3>Gender: 
									<?php
										if($user[0] -> gender == 'M'){
											echo 'Male';
										}
										else{
											echo 'Female';
										}
									?>
									</h3> 

									<h3>Hire Date: {{ $user[0] -> hire_date }}</h3>
									<h3>Profession: {{ $profession[0] -> title }}</h3>
									<h3>Current salary: {{ $salary[0] -> salary }} </h3>
									<h3>dept_name: {{ $dept[0] -> dept_name }}</h3>

							
				        		</div>
				        
				        	</div>
				        </div>
			        </section>




<h2>History</h2>

<div class="limiter">
		<div class="container-table100">
			<div class="wrap-table100">
				<div class="table100 ver1 m-b-110">
				<table data-vertable="ver1">
				<thead>
					<tr class="row100 head">
					<th class="column100 column1" data-column="column1">Profession</th>
					<th class="column100 column2" data-column="column2">Salary</th>
					<th class="column100 column3" data-column="column3">from_date</th>
					<th class="column100 column4" data-column="column4">to_date</th>
					<th class="column100 column5" data-column="column5">Department</th>
					</tr>
				</thead>
			



	<?php
		foreach ($history as $key => $value) {
			?>
			<tbody>
			<tr class="row100">
			<td class="column100 column1" data-column="column1" >{{$value -> title}}</td>

			<td class="column100 column2" data-column="column2" >{{$value -> salary}}</td>

			<td class="column100 column3" data-column="column3">{{$value -> from_date}}</td>

			<td class="column100 column4" data-column="column4">{{$value -> to_date}}</td>

			<td class="column100 column5" data-column="column5">{{$value -> dept_name}}</td>
			</tr>
		</tbody>
			<?php
		}

	?>


</table>
</div>
</div>
</div>
</div>

<section class="testimonial-section section-padding">
			            <div class="container text-center">
			              
			              <hr>

			              <div class="partner-section">
				              <div class="row row-content">
				              	<div class="col-md-12">
									<div class="owl-carousel partner-carousel">
									    <div class="item">
									    	<a href="#"><img src="img/partner/p1.jpg" alt=""></a>
									    </div>
									    <div class="item">
									    	<a href="#"><img src="img/partner/p2.jpg" alt=""></a>
									    </div>
									    <div class="item">
									    	<a href="#"><img src="img/partner/p3.jpg" alt=""></a>
									    </div>
									    <div class="item">
									    	<a href="#"><img src="img/partner/p4.jpg" alt=""></a>
									    </div>
									    <div class="item">
									    	<a href="#"><img src="img/partner/p5.jpg" alt=""></a>
									    </div>
									    <div class="item">
									    	<a href="#"><img src="img/partner/p1.jpg" alt=""></a>
									    </div>
									    <div class="item">
									    	<a href="#"><img src="img/partner/p2.jpg" alt=""></a>
									    </div>
									    <div class="item">
									    	<a href="#"><img src="img/partner/p3.jpg" alt=""></a>
									    </div>
									    <div class="item">
									    	<a href="#"><img src="img/partner/p4.jpg" alt=""></a>
									    </div>
									</div>


							        <div class="partner-carousel-navigation">
							            <a class="prev"><i class="fa fa-angle-left"></i></a>
							            <a class="next"><i class="fa fa-angle-right"></i></a>
							        </div><!-- /.partner-carousel-navigation -->


				              	</div><!-- /.col-md-12 -->
				              </div><!-- /.row -->
			              </div><!-- /.partner-section -->
			            </div><!-- /.container -->
			        </section>
			        <!-- testimonial-section end -->

			        <!-- counter start -->
			        <section class="counter-section" data-stellar-background-ratio="0.5">
			        	<div class="container">
							<div class="row">
						        <div class="col-sm-4 col-xs-12">
						          <div class="counter-block">
						          	<span class="count-description flaticon-boat"><strong class="timer">799</strong>order delivered</span>
						          </div>
						        </div> 
						       <div class="col-sm-4 col-xs-12">
						          <div class="counter-block">
						          	<span class="count-description flaticon-international"><strong class="timer">19</strong>order delivered</span>
						          </div>
						        </div> 
						       <div class="col-sm-4 col-xs-12">
						          <div class="counter-block">
						          	<span class="count-description flaticon-compass"><strong class="timer">521</strong>order delivered</span>
						          </div>
						        </div> 
					      	</div> <!-- /.row -->
			        	</div><!-- /.container -->
			        </section><!-- /.counter-section -->
			        <!-- counter end -->

			        <!-- cta start -->
			        <section class="cta-section">
			        	<div class="container text-center">
			        		<a data-toggle="modal" data-target="#quoteModal" href="#" class="btn btn-primary quote-btn">Get a Quote</a>

							<!-- Modal -->
							<div class="modal fade" id="quoteModal" tabindex="-1" role="dialog" aria-labelledby="quoteModalLabel" aria-hidden="true">
							  <div class="modal-dialog modal-lg">
							    <div class="modal-content">
							      <div class="modal-header">
							        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							        <h3 class="modal-title" id="quoteModalLabel">Request a rate for the shipping of your goods.</h3>
							      </div>
							      <div class="modal-body">
									<form id="contactForm" action="sendemail.php" method="POST">
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
												    <label for="name">Name</label>
												    <input id="name" name="name" type="text" class="form-control"  required="" placeholder="">
												</div>
											</div>
											<div class="col-md-6">
											  <div class="form-group">
											    <label for="company">Company Name</label>
											    <input id="company" name="company" type="text" class="form-control" placeholder="">
											  </div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6">
											  <div class="form-group">
											    <label for="phone">Phone Number</label>
											    <input id="phone" name="phone" type="text" class="form-control" placeholder="">
											  </div>
											</div>
											<div class="col-md-6">
											  <div class="form-group">
											    <label for="email">Email address</label>
											    <input id="email" name="email" type="email" class="form-control" required="" placeholder="">
											  </div>
											</div>
										</div>

										<div class="row">
											<div class="col-md-6">
											  <div class="form-group">
											    <label for="city">City Name</label>
											    <input id="city" name="city" type="text" class="form-control" placeholder="">
											  </div>
											</div>
											<div class="col-md-6">
											  <div class="form-group">
											    <label for="subject">Subject</label>
											    <input id="subject" name="subject" type="text" class="form-control" required="" placeholder="">
											  </div>
											</div>
										</div>
										<div class="form-group text-area">
											<label for="message">Your Message</label>
											<textarea id="message" name="message" class="form-control" rows="6" required="" placeholder=""></textarea>
										</div>

										<button type="submit" class="btn btn-primary">Send Message</button>
									</form>
							      </div>
							    </div>
							  </div>
							</div>

			        	</div><!-- /.container -->
			        </section><!-- /.cta-section -->
			        <!-- cta end -->

			        <!-- footer-widget-section start -->
			       <!-- /.cta-section -->
			        <!-- footer-widget-section end -->

			        <!-- copyright-section start -->
			        <footer class="copyright-section">
			        	<div class="container text-center">
			        		<div class="footer-menu">
			        			<ul>
			        				<li><a href="#">Privacy &amp; Cookies</a></li>
			        				<li><a href="#">Terms &amp; Conditions</a></li>
			        				<li><a href="#">Accessibility</a></li>
			        			</ul>
			        		</div>

			        		<div class="copyright-info">
			        			<span>Copyright © 2018 Unship. All Rights Reserved.</span>
			        		</div>
			        	</div><!-- /.container -->
			        </footer>
			        <!-- copyright-section end -->
	    		</div> <!-- .st-content -->
		    </div> <!-- .st-pusher -->
			
			<!-- OFF CANVAS MENU -->
	    	<!-- .offcanvas-menu -->
		</div><!-- /st-container -->


		<!-- Preloader -->



	<!-- table js-->
<!--	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="vendor/select2/select2.min.js"></script>
	<script src="js/main.js"></script>-->

    <!-- page js-->
    <script src="js/jquery.js"></script>
	    <!-- Bootstrap Core JavaScript -->
	    <script src="js/bootstrap.min.js"></script>
	    <!-- owl.carousel -->
	    <script src="owl.carousel/owl.carousel.min.js"></script>
	    <!-- Magnific-popup -->
		<script src="js/jquery.magnific-popup.min.js"></script>
		<!-- Offcanvas Menu -->
		<script src="js/hippo-offcanvas.js"></script>
		<!-- inview -->
		<script src="js/jquery.inview.min.js"></script>
		<!-- stellar -->
		<script src="js/jquery.stellar.js"></script>
		<!-- countTo -->
		<script src="js/jquery.countTo.js"></script>
		<!-- classie -->
		<script src="js/classie.js"></script>
		<!-- selectFx -->
		<script src="js/selectFx.js"></script>
		<!-- sticky kit -->
		<script src="js/jquery.sticky-kit.min.js"></script>
	    <!-- GOGLE MAP -->
	    <script src="https://maps.googleapis.com/maps/api/js"></script>
	    <!--TWITTER FETCHER-->
	    <script src="js/twitterFetcher_min.js"></script>
	    <!-- Custom Script -->
	    <script src="js/scripts.js"></script>
	</body>
</html>