<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Salaries extends Model
{
    	protected $table = 'salaries';
    	
		public $timestamps = false;
}
