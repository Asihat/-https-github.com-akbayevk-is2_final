<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\View;
use App\Departments;
use App\Dept_emp;
use App\Salaries;
use App\Dept_manager;
use App\Employees;
use Illuminate\Http\Request;
use DB;
use App\Quotation;
class DepController extends Controller
{
    public function index(){
 
    	//$salaries_table = DB::table('dept_emp')
    	$salaries_table = Dept_emp::join('salaries','salaries.emp_no','=','dept_emp.emp_no')
    	->join('departments','departments.dept_no' , '=' , 'dept_emp.dept_no')
    	->select('departments.dept_name  as label',DB::raw('avg(salaries.salary) as value', 'dept_emp.dept_no' ))
    	->groupBy('dept_emp.dept_no')->get();	

    	$wage_growth = Salaries::join('dept_emp','salaries.emp_no','=','dept_emp.emp_no')
    	->select (DB::raw('DATE_FORMAT(salaries.from_date, "%Y") as months'),
    		DB::raw('avg(.salaries.salary) as value'))
    	->where('dept_emp.dept_no','=', 'd002')
    	->groupBy('months')->get();	

    	$wage_bar = Salaries::join('dept_emp','salaries.emp_no','=','dept_emp.emp_no')
    	->select (DB::raw('DATE_FORMAT(salaries.from_date, "%Y") as months'),
    		DB::raw('avg(.salaries.salary) as value1'))
    	->where('dept_emp.dept_no','=', 'd001')
    	->groupBy('months')->get();	
         $count = Employees::select(DB::raw('emp_no'))->count();

          $gender = Employees::select(
            DB::raw('COUNT(employees.emp_no) as value'),
            DB::raw('employees.gender as label'))
            ->groupBy('employees.gender')->get();

          //  print_r(json_encode($gender));
		//$result = array_merge_recursive($wage_growth, $wage_bar);
    	//$this->layout->content = View::make('depinfo', compact('salaries_table'));
    	// print_r(json_encode($gender -> toArray()));
        // print_r(json_encode($gender));
       //	$dep = DB::table('dept_manager')-> select('dept_no') -> get();
 			/*$AVGsalary = array();
 			$i=0;
		foreach($salaries_table as $key => $val){

			if($salaries_table[$i][$val->dept_name]){
				 $AVGsalary[$key] = $val;
			}
		  $i++;
		  unset($salaries_table[$key]); }


		*/


		 //return $salaries_table;		
    return view('depinfo', ['dep' => $salaries_table, 'wage' => $wage_growth,'bar' => $wage_bar, 'gend' => $gender]);
    }


 	public function page(){



 		/*$manager = Dept_manager::join('employees','employees.emp_no','=','dept_manager.emp_no')
    	->join('departments','departments.dept_no' , '=' , 'dept_manager.dept_no')
    	->select('employees.first_name as FirstName','departments.dept_name as DeptName', 'dept_manager.to_date as ToDate' )
    	//->where('dept_manager.to_date','>=', 'dept_manager.from_date')
    	->groupBy('DeptName')->having('dept_manager.to_date','>=', 'dept_manager.from_date')->get();	
		//print_r(json_encode($manager -> toArray()));print_r(json_encode($manager -> toArray()));*/
        $q = Departments::select(DB::raw('dept_no'))->count();
        //echo mysql_result($q, 0);

 		//print_r(json_encode($q ));
        $manager = Dept_manager::join('employees','dept_manager.emp_no','=','employees.emp_no')
    	->join('departments','dept_manager.dept_no' , '=' ,'departments.dept_no' )
    	->select(
            DB::raw('dept_manager.emp_no as ID'),
    		DB::raw('first_name as FirstName'),
            DB::raw('departments.dept_name as DeptName'),
    		DB::raw('dept_manager.from_date as FromDate'))
           ->orderBy('dept_manager.to_date', 'DESC')->take($q)->get();
    		//->where('dept_manager.to_date','<=', 'dept_manager.from_date')
    		//->groupBy('dept_manager.dept_no')
    		
    	//->select('employees.first_name as FirstName','departments.dept_name as DeptName', 'dept_manager.to_date as ToDate' )
    	// print_r(json_encode($manager -> toArray()));print_r(json_encode($manager -> toArray()));
    		//print_r(json_encode($manager -> toArray()));
    	

 		return view('info', ['top' => $manager]);
}

    public function view(){

        $id = request('id');
       // echo $id;


        $table = Salaries::join('dept_emp','salaries.emp_no','=','dept_emp.emp_no')
        ->select (DB::raw('DATE_FORMAT(salaries.from_date, "%Y") as months'),
            DB::raw('avg(.salaries.salary) as value'))
        ->where('dept_emp.emp_no','=', $id)
        ->groupBy('months')->get(); 

        $info = $id;

        $info = Employees::join('dept_manager','dept_manager.emp_no','=','employees.emp_no')
        ->join('departments','dept_manager.dept_no' , '=' ,'departments.dept_no' )
        ->select(
            DB::raw('dept_manager.emp_no as ID'),
            DB::raw('first_name as FirstName'),
            DB::raw('last_name as LastName'),
            DB::raw('departments.dept_name as DeptName'),
             DB::raw('employees.birth_date as BirthDate'),
            DB::raw('dept_manager.from_date as FromDate'))
            ->where('dept_manager.emp_no','=', $id)->get();
        //print_r(json_encode($info -> toArray()));    

        return view('info_manager', ['manager_name' => $info, 'table_info' => $table]);
    }


}
