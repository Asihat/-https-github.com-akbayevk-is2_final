<?php

namespace App\Http\Controllers;
use DB;
use App\Quotation;
use Illuminate\Http\Request;
use App\Post;
use App\Employees;

use App\Departments;
use Validator;
use Response;
use Illuminate\Support\Facades\Input;
use App\http\Requests;
class PostController extends Controller
{
         
    public function index(){
function objectToArray($d) {
        if (is_object($d)) {
            // Gets the properties of the given object
            // with get_object_vars function
            $d = get_object_vars($d);
        }
    
        if (is_array($d)) {
            /*
            * Return array converted to object
            * Using __FUNCTION__ (Magic constant)
            * for recursive call
            */
            return array_map(__FUNCTION__, $d);
        }
        else {
            // Return array
            return $d;
        }
    }     

        $cat = Departments::all();




      if(request()->has('name')){
        
        

        $post = Employees::where('first_name', '=', request('first_name')) -> where('last_name', '=', request('last_name'))  
                          -> paginate(4) 
                          -> appends('first_name', request('name'));
      



      }
      else if(request()->has('type')){
          $post = Employees::join('dept_emp', 'employees.emp_no', '=', 'dept_emp.emp_no') 
                                         -> join('departments', 'dept_emp.dept_no', '=', 'departments.dept_no')
                                         -> where('departments.dept_name', '=', request('type'))
                                         -> select('employees.*') 
                                         ->  paginate(4)
                                         -> appends('type', request('type')); 
                                         

                                         //$post = json_decode($post1, true);
                                        //print_r($post1);

                                        //die();
                                          
                                          //$post = json_encode('stdClass Object', true);
                                          /*foreach ($post as $key => $value) {
                                            $post -> key = (array) $value;
                                          }
                                          die();                                  

                                         /*
                                                
                                                foreach($stdArray as $key => $value)
                                                {
                                                    $stdArray[$key] = (array) $value;
                                                }   


                                         */
                                           

                  }                      
      else{
       // $post = DB::table('employees') -> paginate(4);

      $post = Employees::paginate(4);
      //print_r($post -> toArray());
      //die();
      }
      return view('post.index', ['post' => $post, 'cat' => $cat ]);
    }
    public function portfolio(){
      //$user = Employees::where('emp_no', '=', request('id'))->get();
      $user = DB::table('employees') -> where('emp_no', '=', request('id')) -> get();
      $profession = DB::table('employees') -> join('titles', 'employees.emp_no', '=', 'titles.emp_no') -> where('employees.emp_no', '=', request('id')) -> where('titles.to_date', '=', '9999-01-01') 
      -> select('titles.title') -> get();

      $salary = DB::table('employees') -> join('salaries', 'employees.emp_no', '=', 'salaries.emp_no') 
                                        -> where('employees.emp_no', '=', request('id'))
                                       -> where('salaries.to_date', '=', '9999-01-01') -> select('salaries.salary') -> get();

      $dept = DB::table('employees') -> join('dept_emp', 'employees.emp_no', '=', 'dept_emp.emp_no')
                                      -> where('employees.emp_no', '=', request('id')) 
                                     ->join('departments', 'departments.dept_no', '=', 'dept_emp.dept_no') 
                                     -> where('dept_emp.to_date', '=', '9999-01-01') 
                                     -> select('departments.dept_name') -> get();

      $history = DB::table('employees') -> join('dept_emp', 'employees.emp_no', '=', 'dept_emp.emp_no')
                                      -> where('employees.emp_no', '=', request('id')) 
                                     ->join('departments', 'departments.dept_no', '=', 'dept_emp.dept_no') 
                                     ->join('titles', 'employees.emp_no', '=', 'titles.emp_no') 
                                     ->join('salaries', 'employees.emp_no', '=', 'salaries.emp_no')
                                     -> select('departments.dept_name', 'titles.title', 'salaries.salary', 
                                        'salaries.from_date', 'salaries.to_date') -> get();
                              
      
    //print_r($student    -> toArray()); 
     // print_r($profession -> toArray());
      //dd($profession);
      //echo $profession;
      //die();
      return view('portfolio', ['user' => $user, 'profession' => $profession, 'salary' => $salary, 'dept' => $dept, 'history' => $history ]);
    }
   
}