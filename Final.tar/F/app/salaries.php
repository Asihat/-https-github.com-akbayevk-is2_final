<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class salaries extends Model
{ 
	protected $table = 'salaries';
}
