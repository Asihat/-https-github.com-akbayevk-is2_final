<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class titles extends Model
{
	 protected $table = 'titles';
}
