<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Dept_manager extends Model
{
    
    	protected $table = 'dept_manager';
    	
		public $timestamps = false;
}