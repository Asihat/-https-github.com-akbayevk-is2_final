<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['middleware' => ['web']], function() {
  Route::resource('/post','PostController'); // localhost:8000/post 
  Route::post('/post', 'PostController@index');
});
Route::get('/portfolio', 'PostController@portfolio')->name('portfolio');


// 

Route::get('/depinfo', 'DepController@index');
Route::resource('/student', 'StudentController');

Route::get('/info', 'DepController@page');
Route::get('/info_manager', 'DepController@view');

Route::get('/about', function(){
	//echo 'h';
	return view('about');
});
